from typing import TypedDict, Optional, Dict, Any, List
from typing_extensions import Annotated
import operator


class AgentState(TypedDict):
    # Input
    input_type: str  # "pdf", "image", "audio", "text"
    file_path: Optional[str]
    text_input: Optional[str]
    patient_id: str
    
    # OCR/STT outputs
    extracted_text: Optional[str]
    confidence: Optional[float]
    
    # Document Save outputs
    report_metadata: Optional[Dict[str, Any]]
    
    # Extraction outputs
    findings: Optional[List[str]]
    values: Optional[Dict[str, Any]]
    
    # Summarizer outputs
    summary: Optional[str]
    key_changes: Optional[str]
    current_values: Optional[Dict[str, Any]]
    
    # Doctor Search outputs
    doctor_type: Optional[str]
    location: Optional[Dict[str, str]]
    search_results: Optional[Dict[str, Any]]
    top_doctors: Optional[List[Dict[str, Any]]]
    total_results: Optional[int]
    raw_search_output: Optional[str] 

    # Final response
    final_response: Optional[str]
    
    # Error handling
    error: Optional[str]
    
    # Routing
    next_step: Optional[str]